package pt.mobilesgmc.modelo;

public class RestClientException extends Exception {

	public RestClientException(String detailMessage) {
		super(detailMessage);
	}
}
